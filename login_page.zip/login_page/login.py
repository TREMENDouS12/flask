import email
from msilib import RadioButtonGroup
from flask import Flask, render_template, request, url_for, redirect
import sqlite3

app=Flask(__name__, template_folder='template')


@app.route('/')
def home():
   return render_template('login.html')
  
def check_email_exists(email):
      #checking if the email entered already exists
     conn =sqlite3.connect('SnMDB.sqlite')
     c=conn.cursor()
     c.execute('''SELECT COUNT(*) FROM tbl_LoginSignUp WHERE EmailAdress=?''',(email,))
     result=c.fetchone()[0]
     c.close()
     return result

result=check_email_exists(email)#calling check email method
 

if __name__=='__main__':
   app.run(debug=True)
