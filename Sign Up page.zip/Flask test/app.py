from flask import Flask, render_template, request, url_for, redirect
import sqlite3

app = Flask(__name__, template_folder='templates')

@app.route('/')
def home():
    return render_template('home.html')

@app.route('/signup', methods=['POST', 'GET'])
def signup():
    if request.method == 'POST': #Getting the data
        staff_number = request.form['StaffNo']
        student_number = request.form['StudentNo']
        email = request.form['EmailAdress']
        password = request.form['Password']
        domain = email.split('@')[-1]
        username = email.split('@')[0]

        radio = request.form.get('options') #Get information from inputs
        fieldStaffNo = request.form.get('StaffNo')
        fieldStudentNo = request.form.get('StudentNo')
        fieldPassword = request.form.get('Password')
        

        def check_email_exists(email): #chacking if the email entered already exists
            conn = sqlite3.connect('SnMDB.sqlite')
            c = conn.cursor()
            c.execute('''SELECT COUNT(*) FROM tbl_LoginSignUp WHERE EmailAdress = ?''', (email,))
            result = c.fetchone()[0]
            c.close()
            return result
        
        result = check_email_exists(email) #calling check email method

        if radio == 'option1' and ((not fieldStaffNo and fieldStudentNo) or 
                                   (not fieldStaffNo and not fieldStudentNo) or
                                   (fieldStaffNo and fieldStudentNo)):  #Validating correct information entered
            return 'Please enter information in all the necessary fields. Unless you are a tutor you must not have both staff number and student number entered.', render_template('register.html')
        elif radio == 'option1' and (domain == 'dut.ac.za' and len(fieldStaffNo) == 8 and len(fieldPassword) >= 8 and result == 0): #Validation email address for staff(correct email domain)
                conn = sqlite3.connect('SnMDB.sqlite')
                c = conn.cursor()
                c.execute('''INSERT INTO tbl_LoginSignUp (StaffNo, StudentNo, EmailAdress, Password) VALUES (?, ?, ?, ?)''',
                        (staff_number, student_number, email, password)) #Adding new staff member into db
                conn.commit()
                conn.close()
                return redirect(url_for("home")) #Back to home page
        elif radio == 'option1' and ((domain != 'dut.ac.za' and len(fieldStaffNo) != 8 and len(fieldPassword) < 8)or 
                                     (domain != 'dut.ac.za' and len(fieldStaffNo) == 8 and len(fieldPassword) >= 8) or 
                                     (domain == 'dut.ac.za' and len(fieldStaffNo) != 8 and len(fieldPassword) >= 8) or
                                     (domain != 'dut.ac.za' and len(fieldStaffNo) != 8 and len(fieldPassword) >= 8) or
                                     (domain != 'dut.ac.za' and len(fieldStaffNo) == 8 and len(fieldPassword) < 8) or
                                     (domain == 'dut.ac.za' and len(fieldStaffNo) != 8 and len(fieldPassword) < 8) or
                                     (domain == 'dut.ac.za' and len(fieldStaffNo) == 8 and len(fieldPassword) < 8) or
                                     (result > 0)): #If staff email domain wrong, redirect to signup page
                return redirect(url_for("signup")) #Refreshes sign up page
        
        
        if (radio == 'option2') and ((not fieldStudentNo and fieldStaffNo) or 
                                   ( fieldStudentNo and fieldStaffNo) or 
                                   (not fieldStudentNo and not fieldStaffNo)): #Validating correct information entered
            return 'Unless you are a staff member or a tutor at DUT, you must only enter your student number in the student number field to register.', render_template('register.html')
        elif (radio == 'option2') and (domain == 'dut4life.ac.za' and username == fieldStudentNo and len(fieldStudentNo) == 8 and len(fieldPassword) >= 11 and result == 0): #Validation email address for student(correct email)
                conn = sqlite3.connect('SnMDB.sqlite')
                c = conn.cursor()
                c.execute('''INSERT INTO tbl_LoginSignUp (StaffNo, StudentNo, EmailAdress, Password) VALUES (?, ?, ?, ?)''',
                        (staff_number, student_number, email, password))#Adding new student into db
                conn.commit()
                conn.close()
                return redirect(url_for("home"))
        else: #If student wrong, redirect to signup page
                return redirect(url_for("signup")) 
        
    return render_template('register.html')

if __name__ == '__main__':
    app.run(debug=True)